<?php
/*
Plugin Name: ATZI Custom Post Type
Plugin URI: https://atztechnology.com/
Description:  This plugin is used for create some custom post type in atzi theme.
Author: Kazi Ramjan Ali
Author URI: https://kaziramjan.com
Version: 1.0.0
Text Domain: atzi
License: GPLv2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/



function cptui_register_my_cpts() {

    /**
     * Post Type: Notices.
     */

    $labels = [
        "name" => __( "Notices", "atzi" ),
        "singular_name" => __( "Notice", "atzi" ),
        "menu_name" => __( "Notice", "atzi" ),
        "all_items" => __( "All Notice", "atzi" ),
        "add_new" => __( "Add Notice", "atzi" ),
        "add_new_item" => __( "Add New Notice", "atzi" ),
        "edit_item" => __( "Edit Notice", "atzi" ),
        "new_item" => __( "New Notice", "atzi" ),
        "view_item" => __( "View Notice", "atzi" ),
        "view_items" => __( "View Notices", "atzi" ),
        "search_items" => __( "Search Notice", "atzi" ),
        "not_found" => __( "No Notice Found", "atzi" ),
        "not_found_in_trash" => __( "No Notice found in trash", "atzi" ),
        "parent" => __( "Notice:)", "atzi" ),
        "featured_image" => __( "Featured image for this Notice", "atzi" ),
        "set_featured_image" => __( "Set featured image for this  Notice", "atzi" ),
        "remove_featured_image" => __( "Remove featured image for this Notice", "atzi" ),
        "use_featured_image" => __( "Use as featured image for this Notice", "atzi" ),
        "archives" => __( "Notice Archive", "atzi" ),
        "insert_into_item" => __( "Insert into Notice", "atzi" ),
        "uploaded_to_this_item" => __( "Uploaded to this Notice", "atzi" ),
        "filter_items_list" => __( "Filter Notice list", "atzi" ),
        "items_list_navigation" => __( "Notice list navigation", "atzi" ),
        "items_list" => __( "Notice list", "atzi" ),
        "attributes" => __( "Notice Attributes", "atzi" ),
        "name_admin_bar" => __( "Notice", "atzi" ),
        "item_published" => __( "Notice published", "atzi" ),
        "item_published_privately" => __( "Notice published privately.", "atzi" ),
        "item_reverted_to_draft" => __( "Notice reverted to draft", "atzi" ),
        "item_scheduled" => __( "Notice scheduled", "atzi" ),
        "item_updated" => __( "Notice updated", "atzi" ),
        "parent_item_colon" => __( "Notice:)", "atzi" ),
    ];

    $args = [
        "label" => __( "Notices", "atzi" ),
        "labels" => $labels,
        "description" => "",
        "public" => true,
        "publicly_queryable" => true,
        "show_ui" => true,
        "show_in_rest" => true,
        "rest_base" => "",
        "rest_controller_class" => "WP_REST_Posts_Controller",
        "rest_namespace" => "wp/v2",
        "has_archive" => "notice",
        "show_in_menu" => true,
        "show_in_nav_menus" => true,
        "delete_with_user" => false,
        "exclude_from_search" => false,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => false,
        "can_export" => false,
        "rewrite" => [ "slug" => "notice", "with_front" => true ],
        "query_var" => true,
        "menu_position" => 6,
        "menu_icon" => "dashicons-sticky",
        "supports" => [ "title", "editor", "revisions" ],
        "show_in_graphql" => false,
    ];

    register_post_type( "notice", $args );

    /**
     * Post Type: Events.
     */

    $labels = [
        "name" => __( "Events", "atzi" ),
        "singular_name" => __( "Event", "atzi" ),
        "menu_name" => __( "Events", "atzi" ),
        "all_items" => __( "All Events", "atzi" ),
        "add_new" => __( "Add Event", "atzi" ),
        "add_new_item" => __( "Add New Event", "atzi" ),
        "edit_item" => __( "Edit Event", "atzi" ),
        "new_item" => __( "New Event", "atzi" ),
        "view_item" => __( "View Event", "atzi" ),
        "view_items" => __( "View Events", "atzi" ),
        "search_items" => __( "Search Events", "atzi" ),
        "not_found" => __( "No Events Found", "atzi" ),
        "not_found_in_trash" => __( "No Events Found in Trash", "atzi" ),
        "parent" => __( "Parent Events:)", "atzi" ),
        "featured_image" => __( "Featured image for this Event", "atzi" ),
        "set_featured_image" => __( "Set featured image for this  Event", "atzi" ),
        "remove_featured_image" => __( "Remove featured image for this Event", "atzi" ),
        "use_featured_image" => __( "Use as featured image for this Event", "atzi" ),
        "archives" => __( "Events Archive", "atzi" ),
        "insert_into_item" => __( "Insert into Event", "atzi" ),
        "uploaded_to_this_item" => __( "Uploaded to this Events", "atzi" ),
        "filter_items_list" => __( "Filter Events list", "atzi" ),
        "items_list_navigation" => __( "Events list navigation", "atzi" ),
        "items_list" => __( "Events list", "atzi" ),
        "attributes" => __( "Events Attributes", "atzi" ),
        "name_admin_bar" => __( "Event", "atzi" ),
        "item_published" => __( "Events published", "atzi" ),
        "item_published_privately" => __( "Events published privately.", "atzi" ),
        "item_reverted_to_draft" => __( "Events reverted to draft", "atzi" ),
        "item_scheduled" => __( "Events scheduled", "atzi" ),
        "item_updated" => __( "Events updated", "atzi" ),
        "parent_item_colon" => __( "Parent Events:)", "atzi" ),
    ];

    $args = [
        "label" => __( "Events", "atzi" ),
        "labels" => $labels,
        "description" => "",
        "public" => true,
        "publicly_queryable" => true,
        "show_ui" => true,
        "show_in_rest" => true,
        "rest_base" => "",
        "rest_controller_class" => "WP_REST_Posts_Controller",
        "rest_namespace" => "wp/v2",
        "has_archive" => "events",
        "show_in_menu" => true,
        "show_in_nav_menus" => true,
        "delete_with_user" => false,
        "exclude_from_search" => false,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => false,
        "can_export" => false,
        "rewrite" => [ "slug" => "events", "with_front" => true ],
        "query_var" => true,
        "menu_position" => 9,
        "menu_icon" => "dashicons-calendar-alt",
        "supports" => [ "title", "editor", "thumbnail", "revisions" ],
        "show_in_graphql" => false,
    ];

    register_post_type( "events", $args );

    /**
     * Post Type: Scholarships.
     */

    $labels = [
        "name" => __( "Scholarships", "atzi" ),
        "singular_name" => __( "Scholarship", "atzi" ),
        "menu_name" => __( "Scholarship", "atzi" ),
        "all_items" => __( "All Scholarship", "atzi" ),
        "add_new" => __( "Add Scholarship", "atzi" ),
        "add_new_item" => __( "Add New Scholarship", "atzi" ),
        "edit_item" => __( "Edit Scholarship", "atzi" ),
        "new_item" => __( "New Scholarship", "atzi" ),
        "view_item" => __( "View Scholarship", "atzi" ),
        "view_items" => __( "View Scholarship", "atzi" ),
        "search_items" => __( "Search Scholarship", "atzi" ),
        "not_found" => __( "No Scholarship Found", "atzi" ),
        "not_found_in_trash" => __( "No Scholarship found in trash", "atzi" ),
        "parent" => __( "Parent Scholarship:)", "atzi" ),
        "featured_image" => __( "Featured image for this Scholarship", "atzi" ),
        "set_featured_image" => __( "Set featured image for this  Scholarship", "atzi" ),
        "remove_featured_image" => __( "Remove featured image for this Scholarship", "atzi" ),
        "use_featured_image" => __( "Use as featured image for this Scholarship", "atzi" ),
        "archives" => __( "Scholarship Archive", "atzi" ),
        "insert_into_item" => __( "Insert into Scholarship", "atzi" ),
        "uploaded_to_this_item" => __( "Uploaded to this Scholarship", "atzi" ),
        "filter_items_list" => __( "Filter Scholarship list", "atzi" ),
        "items_list_navigation" => __( "Scholarship list navigation", "atzi" ),
        "items_list" => __( "Scholarship list", "atzi" ),
        "attributes" => __( "Scholarship Attributes", "atzi" ),
        "name_admin_bar" => __( "Scholarship", "atzi" ),
        "item_published" => __( "Scholarship published", "atzi" ),
        "item_published_privately" => __( "Scholarship published privately.", "atzi" ),
        "item_reverted_to_draft" => __( "Scholarship reverted to draft", "atzi" ),
        "item_scheduled" => __( "Scholarship scheduled", "atzi" ),
        "item_updated" => __( "Scholarship updated", "atzi" ),
        "parent_item_colon" => __( "Parent Scholarship:)", "atzi" ),
    ];

    $args = [
        "label" => __( "Scholarships", "atzi" ),
        "labels" => $labels,
        "description" => "",
        "public" => true,
        "publicly_queryable" => true,
        "show_ui" => true,
        "show_in_rest" => true,
        "rest_base" => "",
        "rest_controller_class" => "WP_REST_Posts_Controller",
        "rest_namespace" => "wp/v2",
        "has_archive" => "scholarship",
        "show_in_menu" => true,
        "show_in_nav_menus" => true,
        "delete_with_user" => false,
        "exclude_from_search" => false,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => false,
        "can_export" => false,
        "rewrite" => [ "slug" => "scholarship", "with_front" => true ],
        "query_var" => true,
        "menu_position" => 9,
        "menu_icon" => "dashicons-welcome-learn-more",
        "supports" => [ "title", "editor", "thumbnail", "comments", "revisions" ],
        "show_in_graphql" => false,
    ];

    register_post_type( "scholarship", $args );

    /**
     * Post Type: Researches.
     */

    $labels = [
        "name" => __( "Researches", "atzi" ),
        "singular_name" => __( "Research", "atzi" ),
        "menu_name" => __( "Research", "atzi" ),
        "all_items" => __( "All Research", "atzi" ),
        "add_new" => __( "Add New Research", "atzi" ),
        "add_new_item" => __( "Add New Research", "atzi" ),
        "edit_item" => __( "Edit Research", "atzi" ),
        "new_item" => __( "New Research", "atzi" ),
        "view_item" => __( "View Research", "atzi" ),
        "view_items" => __( "View Research", "atzi" ),
        "search_items" => __( "Search Research", "atzi" ),
        "not_found" => __( "No Research Found", "atzi" ),
        "not_found_in_trash" => __( "Not Found in Trash", "atzi" ),
        "parent" => __( "Parent Research:)", "atzi" ),
        "featured_image" => __( "Featured image for this Research", "atzi" ),
        "set_featured_image" => __( "Set featured image for this  Research", "atzi" ),
        "remove_featured_image" => __( "Remove featured image for this Research", "atzi" ),
        "use_featured_image" => __( "Use as featured image for this Research", "atzi" ),
        "archives" => __( "Research Archive", "atzi" ),
        "insert_into_item" => __( "Insert into Research", "atzi" ),
        "uploaded_to_this_item" => __( "Uploaded to this Research", "atzi" ),
        "filter_items_list" => __( "Filter Research list", "atzi" ),
        "items_list_navigation" => __( "Research list navigation", "atzi" ),
        "items_list" => __( "Research list", "atzi" ),
        "attributes" => __( "Research Attributes", "atzi" ),
        "name_admin_bar" => __( "Research", "atzi" ),
        "item_published" => __( "Research published", "atzi" ),
        "item_published_privately" => __( "Research published privately.", "atzi" ),
        "item_reverted_to_draft" => __( "Research reverted to draft", "atzi" ),
        "item_scheduled" => __( "Research scheduled", "atzi" ),
        "item_updated" => __( "Research updated", "atzi" ),
        "parent_item_colon" => __( "Parent Research:)", "atzi" ),
    ];

    $args = [
        "label" => __( "Researches", "atzi" ),
        "labels" => $labels,
        "description" => "",
        "public" => true,
        "publicly_queryable" => true,
        "show_ui" => true,
        "show_in_rest" => true,
        "rest_base" => "",
        "rest_controller_class" => "WP_REST_Posts_Controller",
        "rest_namespace" => "wp/v2",
        "has_archive" => "research",
        "show_in_menu" => true,
        "show_in_nav_menus" => true,
        "delete_with_user" => false,
        "exclude_from_search" => false,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => false,
        "can_export" => false,
        "rewrite" => [ "slug" => "research", "with_front" => true ],
        "query_var" => true,
        "menu_position" => 8,
        "menu_icon" => "dashicons-media-document",
        "supports" => [ "title", "editor", "thumbnail", "revisions" ],
        "show_in_graphql" => false,
    ];

    register_post_type( "research", $args );

    /**
     * Post Type: Teachers.
     */

    $labels = [
        "name" => __( "Teachers", "atzi" ),
        "singular_name" => __( "Teacher", "atzi" ),
        "menu_name" => __( "Teacher", "atzi" ),
        "all_items" => __( "All Teacher", "atzi" ),
        "add_new" => __( "Add Teacher", "atzi" ),
        "add_new_item" => __( "Add New Teacher", "atzi" ),
        "edit_item" => __( "Edit Teacher", "atzi" ),
        "new_item" => __( "New Teacher", "atzi" ),
        "view_item" => __( "View Teacher", "atzi" ),
        "view_items" => __( "View Teacher", "atzi" ),
        "search_items" => __( "Search Teacher", "atzi" ),
        "not_found" => __( "No Teacher Found", "atzi" ),
        "not_found_in_trash" => __( "No Teacher found in trash", "atzi" ),
        "parent" => __( "Parent Teacher:)", "atzi" ),
        "featured_image" => __( "Featured image for this Teacher", "atzi" ),
        "set_featured_image" => __( "Set featured image for this Teacher", "atzi" ),
        "remove_featured_image" => __( "Remove featured image for this Teacher", "atzi" ),
        "use_featured_image" => __( "Use as featured image for this Teacher", "atzi" ),
        "archives" => __( "Teacher Archive", "atzi" ),
        "insert_into_item" => __( "Insert into Teacher", "atzi" ),
        "uploaded_to_this_item" => __( "Uploaded to this Teacher", "atzi" ),
        "filter_items_list" => __( "Filter Teacher list", "atzi" ),
        "items_list_navigation" => __( "Teacher list navigation", "atzi" ),
        "items_list" => __( "Teacher list", "atzi" ),
        "attributes" => __( "Teacher Attributes", "atzi" ),
        "name_admin_bar" => __( "Teacher", "atzi" ),
        "item_published" => __( "Teacher published", "atzi" ),
        "item_published_privately" => __( "Teacher published privately.", "atzi" ),
        "item_reverted_to_draft" => __( "Teacher reverted to draft", "atzi" ),
        "item_scheduled" => __( "Teacher scheduled", "atzi" ),
        "item_updated" => __( "Teacher updated", "atzi" ),
        "parent_item_colon" => __( "Parent Teacher:)", "atzi" ),
    ];

    $args = [
        "label" => __( "Teachers", "atzi" ),
        "labels" => $labels,
        "description" => "",
        "public" => true,
        "publicly_queryable" => true,
        "show_ui" => true,
        "show_in_rest" => true,
        "rest_base" => "",
        "rest_controller_class" => "WP_REST_Posts_Controller",
        "rest_namespace" => "wp/v2",
        "has_archive" => "teachers",
        "show_in_menu" => true,
        "show_in_nav_menus" => true,
        "delete_with_user" => false,
        "exclude_from_search" => false,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => false,
        "can_export" => false,
        "rewrite" => [ "slug" => "teachers", "with_front" => true ],
        "query_var" => true,
        "menu_position" => 7,
        "menu_icon" => "dashicons-businessman",
        "supports" => [ "title", "thumbnail", "revisions" ],
        "taxonomies" => [ "teacher-department-category" ],
        "show_in_graphql" => false,
    ];

    register_post_type( "teachers", $args );
}

add_action( 'init', 'cptui_register_my_cpts' );



function cptui_register_my_taxes() {

    /**
     * Taxonomy: Speakers.
     */

    $labels = [
        "name" => __( "Speakers", "atzi" ),
        "singular_name" => __( "Speaker", "atzi" ),
        "menu_name" => __( "Speaker", "atzi" ),
        "all_items" => __( "All Speaker", "atzi" ),
        "edit_item" => __( "Edit Speaker", "atzi" ),
        "view_item" => __( "View Speaker", "atzi" ),
        "update_item" => __( "Update Speaker Name", "atzi" ),
        "add_new_item" => __( "Add New Speaker", "atzi" ),
        "new_item_name" => __( "New Speaker Name", "atzi" ),
        "parent_item" => __( "Parent Speaker", "atzi" ),
        "parent_item_colon" => __( "Parent Speaker:)", "atzi" ),
        "search_items" => __( "Search Speakers", "atzi" ),
        "popular_items" => __( "Popular Speakers", "atzi" ),
        "separate_items_with_commas" => __( "Separate Speaker with Commas", "atzi" ),
        "add_or_remove_items" => __( "Add or Remove Speaker", "atzi" ),
        "choose_from_most_used" => __( "Choose From Most Used Speaker", "atzi" ),
        "not_found" => __( "No Speaker Found", "atzi" ),
        "no_terms" => __( "No Speaker", "atzi" ),
        "items_list_navigation" => __( "Speaker List Navigation", "atzi" ),
        "items_list" => __( "Speaker List", "atzi" ),
        "back_to_items" => __( "Back to Speaker", "atzi" ),
    ];

    
    $args = [
        "label" => __( "Speakers", "atzi" ),
        "labels" => $labels,
        "public" => true,
        "publicly_queryable" => true,
        "hierarchical" => false,
        "show_ui" => true,
        "show_in_menu" => true,
        "show_in_nav_menus" => true,
        "query_var" => true,
        "rewrite" => [ 'slug' => 'speaker', 'with_front' => true, ],
        "show_admin_column" => false,
        "show_in_rest" => true,
        "show_tagcloud" => false,
        "rest_base" => "speaker",
        "rest_controller_class" => "WP_REST_Terms_Controller",
        "rest_namespace" => "wp/v2",
        "show_in_quick_edit" => false,
        "sort" => false,
        "show_in_graphql" => false,
    ];
    register_taxonomy( "speaker", [ "events" ], $args );

    /**
     * Taxonomy: Departments.
     */

    $labels = [
        "name" => __( "Departments", "atzi" ),
        "singular_name" => __( "Department", "atzi" ),
        "menu_name" => __( "Department", "atzi" ),
        "all_items" => __( "All Department", "atzi" ),
        "edit_item" => __( "Edit Department", "atzi" ),
        "view_item" => __( "View Department", "atzi" ),
        "update_item" => __( "Update Department Name", "atzi" ),
        "add_new_item" => __( "Add New Department", "atzi" ),
        "new_item_name" => __( "New Department Name", "atzi" ),
        "parent_item" => __( "Parent Department", "atzi" ),
        "parent_item_colon" => __( "Parent Department:)", "atzi" ),
        "search_items" => __( "Search Departments", "atzi" ),
        "popular_items" => __( "Popular Departments", "atzi" ),
        "separate_items_with_commas" => __( "Separate Department with Commas", "atzi" ),
        "add_or_remove_items" => __( "Add or Remove Department", "atzi" ),
        "choose_from_most_used" => __( "Choose From Most Used Department", "atzi" ),
        "not_found" => __( "No Department Found", "atzi" ),
        "no_terms" => __( "No Department", "atzi" ),
        "items_list_navigation" => __( "Department List Navigation", "atzi" ),
        "items_list" => __( "Department List", "atzi" ),
        "back_to_items" => __( "Back to Department", "atzi" ),
    ];

    
    $args = [
        "label" => __( "Departments", "atzi" ),
        "labels" => $labels,
        "public" => true,
        "publicly_queryable" => true,
        "hierarchical" => false,
        "show_ui" => true,
        "show_in_menu" => true,
        "show_in_nav_menus" => true,
        "query_var" => true,
        "rewrite" => [ 'slug' => 'department', 'with_front' => true, ],
        "show_admin_column" => false,
        "show_in_rest" => true,
        "show_tagcloud" => false,
        "rest_base" => "department",
        "rest_controller_class" => "WP_REST_Terms_Controller",
        "rest_namespace" => "wp/v2",
        "show_in_quick_edit" => false,
        "sort" => false,
        "show_in_graphql" => false,
    ];
    register_taxonomy( "department", [ "teachers" ], $args );
}
add_action( 'init', 'cptui_register_my_taxes' );
